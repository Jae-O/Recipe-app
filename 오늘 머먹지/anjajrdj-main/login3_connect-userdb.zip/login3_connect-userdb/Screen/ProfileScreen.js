import React from 'react';
import { View, Text, Button } from 'react-native';

const ProfileScreen = ({ navigation }) => {
  const handleLogout = () => {
    // 로그아웃 처리 로직 작성
    // ...

    // 로그아웃 시 로그인 화면으로 이동
    navigation.navigate('Login');
  };

  return (
    <View>
      <Text>Profile Screen</Text>
      <Button title="로그아웃" onPress={handleLogout} />
    </View>
  );
};

export default ProfileScreen;
