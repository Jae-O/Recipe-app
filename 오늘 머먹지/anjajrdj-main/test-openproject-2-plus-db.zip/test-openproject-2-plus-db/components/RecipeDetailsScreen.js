import React from 'react';
import { View, Text } from 'react-native';

const RecipeDetailsScreen = ({ route }) => {
  const { recipe } = route.params;

  return (
    <View>
      <Text>{recipe.title}</Text>
      <Text>{recipe.description}</Text>
      {/* 기타 레시피의 상세 정보를 표시하는 코드 */}
    </View>
  );
};

export default RecipeDetailsScreen;
