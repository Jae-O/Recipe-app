import firebase from 'firebase'

const firebaseConfig = {
  apiKey: "AIzaSyBY5aZ1M_nN9So4D28g9okxDdRptwW-q44",
  authDomain: "oss-project-58ecd.firebaseapp.com",
  projectId: "oss-project-58ecd",
  storageBucket: "oss-project-58ecd.appspot.com",
  messagingSenderId: "823422862103",
  appId: "1:823422862103:web:7f5ddfa0d92365da00ed52",
  measurementId: "G-YWTXZ3PHEZ"
};

const app = firebase.initializeApp(firebaseConfig);
const db = firebase.firestore(app);

export { db }