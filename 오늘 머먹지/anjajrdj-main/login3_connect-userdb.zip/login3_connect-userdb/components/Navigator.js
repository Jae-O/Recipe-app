import { createStackNavigator } from 'react-navigation-stack';
import LoginScreen from '../Screen/LoginScreen';
import SignUpScreen from '../Screen/SignupScreen';

const AppNavigator = createStackNavigator(
  {
    Login: { screen: LoginScreen },
    SignUp: { screen: SignUpScreen },
  },
  {
    initialRouteName: 'Login',
  }
);
