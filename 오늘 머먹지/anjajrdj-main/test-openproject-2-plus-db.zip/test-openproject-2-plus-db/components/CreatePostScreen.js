import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { db } from '../firebaseConfig';

const CreatePostScreen = ({ navigation }) => {
  const [title, setTitle] = useState('');
  const [ingredients, setIngredients] = useState([]);
  const [recipe, setRecipe] = useState([]);
  const [tag, setTag] = useState([]);
  const [comment, setComment] = useState('');

  const handlePost = () => {
    // 글 작성 동작을 수행합니다.
    console.log('Creating a post:', { title, recipe, ingredients });
    addtoCommu();
    addtoRecipe();
    // ...
    // 글 작성 후, 커뮤니티 스크린으로 이동합니다.
    navigation.navigate('Community');
  };

  const handleAddtitle = (event) => {
    setTitle(event);
  };

  const handleAddComment = (event) => {
    setComment(event);
  };

  const handleAddtag = () => {
    setTag([...tag, '']);
  };

  const handleAddIngredient = () => {
    setIngredients([...ingredients, '']);
  };

  const handleAddRecipe = () => {
    setRecipe([...recipe, '']);
  };

  const handleChangeIngredient = (index, value) => {
    const inputs = [...ingredients];
    inputs[index] = value;
    setIngredients(inputs);
  };

  const handleChangeRecipe = (index, value) => {
    const inputs = [...recipe];
    inputs[index] = value;
    setRecipe(inputs);
  };

  const handleChangeTag = (index, value) => {
    const inputs = [...tag];
    inputs[index] = value;
    setTag(inputs);
  };

  const addtoRecipe = async () => {
    try {
      const docRef = await db.collection('Recipe').doc();
      const recipeMap = {};

      // recipe 배열의 각 요소를 맵에 추가
      recipe.forEach((step, index) => {
        recipeMap[`Step${index + 1}`] = step;
      });

      await docRef.set({
        요리이름: title,
        재료: [...ingredients],
        조리법: recipeMap,
        해쉬태그: [...tag],
        인덱스 : docRef.id,
        별점: '',
      });
    } catch (error) {
      console.log(error.message);
    }
  };

  const addtoCommu = async () => {
    try {
      const docRef = await db.collection('Community').doc();
      const recipeMap = {};

      // recipe 배열의 각 요소를 맵에 추가
      recipe.forEach((step, index) => {
        recipeMap[`Step${index + 1}`] = step;
      });

      await docRef.set({
        요리이름: title,
        재료: [...ingredients],
        조리법: recipeMap,
        해쉬태그: [...tag],
        코멘트 : comment,
        댓글: [''],
        인덱스 : docRef.id
      });
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>글 작성</Text>
      <ScrollView>
        <View>
          <Text>이름</Text>
          <TextInput
            style={styles.input}
            placeholder="요리이름"
            value={title}
            onChangeText={handleAddtitle}
          />
        </View>
        <View style={styles.inputContainer}>
          <Text>재료</Text>
          <ScrollView>
            {ingredients.map((input, index) => (
              <TextInput
                key={index}
                style={styles.input}
                placeholder="재료입력"
                value={input}
                onChangeText={(value) => handleChangeIngredient(index, value)}
              />
            ))}
            <Button title="재료추가" onPress={handleAddIngredient} />
          </ScrollView>
        </View>
        <View style={styles.inputContainer}>
          <Text>레시피</Text>
          <ScrollView>
            {recipe.map((input, index) => (
              <TextInput
                key={index}
                style={styles.input}
                placeholder={`Step ${index + 1}`}
                value={input}
                onChangeText={(value) => handleChangeRecipe(index, value)}
              />
            ))}
            <Button title="레시피 추가" onPress={handleAddRecipe} />
          </ScrollView>
        </View>
        <View>
          <Text>hashTags</Text>
          <ScrollView>
            {tag.map((input, index) => (
              <TextInput
                key={index}
                style={styles.input}
                placeholder={`#tag ${index + 1}`}
                value={input}
                onChangeText={(value) => handleChangeTag(index, value)}
              />
            ))}
            <Button title="태그 추가" onPress={handleAddtag} />
          </ScrollView>
        </View>
        <View>
          <Text>코멘트</Text>
          <TextInput
            style={styles.inputComment}
            placeholder="추가적인 코멘트 입력"
            multiline={true}
            maxLength={300}
            value={comment}
            onChangeText={handleAddComment}
          />
        </View>
      </ScrollView>
      <View style={styles.buttonContainer}>
        <Button title="글 작성" onPress={handlePost} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  inputContainer: {
    flex: 1,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  inputComment: {
    height: 80,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  buttonContainer: {
    alignSelf: 'flex-end',
    bottom: -10,
  },
});

export default CreatePostScreen;
