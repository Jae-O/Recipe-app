import firebase from 'firebase'
// import { initializeFirestore } from "firebase/firestore"

const firebaseConfig = {
  apiKey: "AIzaSyBY5aZ1M_nN9So4D28g9okxDdRptwW-q44",
  authDomain: "oss-project-58ecd.firebaseapp.com",
  projectId: "oss-project-58ecd",
  storageBucket: "oss-project-58ecd.appspot.com",
  messagingSenderId: "823422862103",
  appId: "1:823422862103:web:e4e9904b0db3805700ed52",
  measurementId: "G-RF0LXLYVEN"
};

const app = firebase.initializeApp(firebaseConfig);
const db = firebase.firestore(app);

export { db }