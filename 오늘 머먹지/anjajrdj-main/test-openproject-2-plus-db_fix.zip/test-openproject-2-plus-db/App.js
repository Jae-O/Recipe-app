import React from 'react';
import { useState } from 'react';
import { View, Text, TextInput, Button, Image, TouchableOpacity, StyleSheet, ScrollView, SafeAreaView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import RecipeDetailsScreen from './components/RecipeDetailsScreen';
import CommunityScreen from './components/CommunityScreen';
import CreatePostScreen from './components/CreatePostScreen'
import DetailPostScreen from './components/DetailPostScreen'

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Home" component={HomeStack} />
        <Tab.Screen name="Favorites" component={SearchScreen} options={{ title: '검색' }} />
        <Tab.Screen name="커뮤니티" component={SettingsScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

const HomeStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
      <Stack.Screen name="KoreanMenuScreen" component={KoreanMenuScreen} options={{ title: '한식' }} />
      <Stack.Screen name="ChineseMenuScreen" component={ChineseMenuScreen} options={{ title: '중식'}} />
      <Stack.Screen name="JapaneseMenuScreen" component={JapaneseMenuScreen} options={{ title: '일식'}} />
      <Stack.Screen name="WesternMenuScreen" component={WesternMenuScreen} options={{ title: '양식'}} />	
      <Stack.Screen name="RecipeDetails" component={RecipeDetailsScreen} options={{ title: '레시피' }} />
      <Stack.Screen name="Community" component={CommunityScreen} options={{ title: '커뮤니티' }} />
      <Stack.Screen name="CreatePost" component={CreatePostScreen} options={{ title: '글 작성' }} />
      <Stack.Screen name="PostDetails" component={DetailPostScreen} options={{ title: '게시판' }} />
    </Stack.Navigator>
  );
};


const HomeScreen = ({ navigation }) => {

  const categories = [
    { name: '한식', image: require('./assets/korean-food.jpg'), screen: 'KoreanMenuScreen', menu: ['김치찌개', '불고기', '비빔밥'] },
    { name: '중식', image: require('./assets/chinese-food.png'), screen: 'ChineseMenuScreen', menu: ['짜장면', '탕수육', '마파두부'] },
    { name: '양식', image: require('./assets/western-food.jpg'), screen: 'WesternMenuScreen', menu: ['스테이크', '파스타', '피자'] },
    { name: '일식', image: require('./assets/japanese-food.png'), screen: 'JapaneseMenuScreen', menu: ['초밥', '라멘', '돈까스'] },
  ];

  const images = [
    {
      name: '불고기',
      image: 'https://search.pstatic.net/common/?src=http%3A%2F%2Fshop1.phinf.naver.net%2F20220707_28%2F165716970036907QvJ_JPEG%2F58305534174877807_853590589.jpg&type=a340',
    },
    {
      name: '짜장면',
      image: 'https://search.pstatic.net/common/?src=https%3A%2F%2Fg-grafolio.pstatic.net%2F20200320_239%2F15846849115493qDG5_JPEG%2Fjja03.jpg%3Ftype%3Dw896_4&type=a340',
    },
    {
      name: '스테이크',
      image: 'https://search.pstatic.net/sunny/?src=https%3A%2F%2Fcdn.crowdpic.net%2Fdetail-thumb%2Fthumb_d_7814FCAF046F7AE78F90EF9C63153FD9.jpg&type=a340',
    },
    {
      name: '초밥',
      image: 'https://search.pstatic.net/common/?src=http%3A%2F%2Fblogfiles.naver.net%2FMjAxODEyMThfMTkz%2FMDAxNTQ1MDY0OTI2MDc4.V1rqIEXyv0VbnwPRCGb_5grSLszBLDcq3y14DgS3bZAg.qPlcSuKI1K3qoOtQn6EO66vzRTIlg0xH9BFFt0Q109Ag.JPEG.catives%2F_MG_3621_%25BA%25B9%25BB%25E7.jpg&type=a340',
    },
  ];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>우리 오늘 뭐먹어?</Text>
      </View>
      <View style={styles.main}>
        <View style={styles.foodImage}>
          <ScrollView horizontal>
            {images.map((image, index) => (
              <Image key={index} source={{ uri: image.image }} style={styles.foodImageItem} />
            ))}
          </ScrollView>
        </View>
        <View style={styles.categoryList}>
          {categories.map((category, index) => (
            <TouchableOpacity
              style={styles.category}
              key={index}
              onPress={() => navigation.navigate(category.screen, { menu: category.menu })}
            >
              <Image source={category.image} style={styles.categoryImage} />
              <Text style={styles.categoryName}>{category.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </View>
  );
};

const SearchScreen = () => {
  const [searchText, setSearchText] = useState('');

  const handleSearch = () => {
    // 검색 기능 구현
    // 검색 결과를 화면에 표시하거나 다른 동작 수행
    console.log('검색어:', searchText);
    // ...
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="검색어를 입력하세요"
        value={searchText}
        onChangeText={setSearchText}
      />
      <Button title="검색" onPress={handleSearch} />
    </View>
  );
};

const SettingsScreen = ({ navigation }) => {
  const handleCommunityPress = () => {
    navigation.navigate('Community');
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.button} onPress={handleCommunityPress}>
        <Text style={styles.buttonText}>커뮤니티</Text>
      </TouchableOpacity>
    </View>
  );
};

const KoreanMenuScreen = ({ route }) => {
  const { menu } = route.params;

  return (
    <View style={styles.menuContainer}>
      <Text style={styles.menuTitle}>한식 메뉴</Text>
      {menu.map((item, index) => (
        <Text style={styles.menuItem} key={index}>{item}</Text>
      ))}
    </View>
  );
};


const ChineseMenuScreen = ({ route }) => {
  const { menu } = route.params;

  return (
    <View style={styles.menuContainer}>
      <Text style={styles.menuTitle}>중식 메뉴</Text>
      {menu.map((item, index) => (
        <Text style={styles.menuItem} key={index}>{item}</Text>
      ))}
    </View>
  );
};

const WesternMenuScreen = ({ route }) => {
  const { menu } = route.params;

  return (
    <View style={styles.menuContainer}>
      <Text style={styles.menuTitle}>양식 메뉴</Text>
      {menu.map((item, index) => (
        <Text style={styles.menuItem} key={index}>{item}</Text>
      ))}
    </View>
  );
};

const JapaneseMenuScreen = ({ route }) => {
  const { menu } = route.params;

  return (
    <View style={styles.menuContainer}>
      <Text style={styles.menuTitle}>일식 메뉴</Text>
      {menu.map((item, index) => (
        <Text style={styles.menuItem} key={index}>{item}</Text>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  main: {
    flex: 1,
    padding: 20,
  },
  foodImage: {
    height: 200,
    marginBottom: 20,
  },
  foodImageItem: {
    width: 200,
    height: 200,
    marginRight: 20,
    borderRadius: 20,
  },
  categoryList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  category: {
    width: '48%',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
  },
  categoryImage: {
    width: '100%',
    height: 100,
    marginBottom: 10,
    borderRadius: 5,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  menuContainer: {
    flex: 1,
    padding: 20,
  },
  menuTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  menuItem: {
    fontSize: 16,
    marginBottom: 5,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
});

export default App;