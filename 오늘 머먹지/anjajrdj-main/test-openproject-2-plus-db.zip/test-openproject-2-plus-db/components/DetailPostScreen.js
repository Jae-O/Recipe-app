import { useEffect, useState } from 'react'
import { View, Text, TextInput, StyleSheet, TouchableOpacity } from 'react-native'
import { db } from '../firebaseConfig'

const DetailPostScreen = ({ route }) => {
  const { postId } = route.params;
  const [name, setName] = useState('')
  const [ingd, setIngd] = useState([])
  const [steps, setSteps] = useState([])
  const [comment, setComment] = useState([])
  const [hashtag, setHashTag] = useState([])
  const [newComment, setNewComment] = useState('')

  const readCommDB = async () => {
    try {
      const doc = await db.collection('Community').doc(postId).get();
      const data = doc.data();
      const { 요리이름, 재료, 조리법, 코멘트, 해쉬태그, 댓글 } = data;
      const CookNames = 요리이름;
      const ingredients = 재료;
      const recipe = 조리법;
      const comm = 코멘트;
      const hTag = 해쉬태그;
      setName(CookNames);
      setIngd(ingredients);
      setComment(comm);
      setHashTag(hTag);

      const extractedSteps = [];
      Object.entries(recipe).forEach(([key, value]) => {
        extractedSteps.push(value);
      });
      setSteps(extractedSteps.reverse());

    } catch (error) {
      console.log(error.message);
    }
  }

  const handleAddComment = () => {
    //댓글기능 추후 추가
  }

  useEffect(() => {
    readCommDB();
  }, []);

  return (
    <View style={styles.container}>
    <View>
    <Text style={styles.title}>{name}</Text>
    <Text style={styles.ingredient}>재료 : {ingd.join(', ')}</Text>
    <Text>조리법 : </Text>
    {steps.map((step, index) => (
      <Text key={index} style={styles.step}>{`Step ${index + 1}: ${step}`}</Text>
    ))}
    <Text style={styles.comment}>{comment}</Text>
    <Text style={styles.hashtag}>{hashtag.join('  ')}</Text>
    </View>
    <View style = {styles.inputView}>
    <TextInput
        style={styles.inputText}
        value={newComment}
        onChangeText={text => setNewComment(text)}
        placeholder="댓글 추가"
        placeholderTextColor="#888"
      />
      <TouchableOpacity onPress={handleAddComment}>
        <View style = {styles.btnshape}>
          <Text>댓글</Text>
        </View>
      </TouchableOpacity>
      </View>
  </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  ingredient: {
    fontSize: 16,
    marginBottom: 20,
  },
  step: {
    fontSize: 16,
    marginBottom: 5,
  },
  comment: {
    fontSize: 14,
    marginTop: 20,
    color: '#666666',
  },
  hashtag: {
    fontSize: 14,
    marginTop: 15,
    color: '#666666',
  },
   inputText: {
    paddingHorizontal: 100,
    paddingVertical: 5,
    height: 40,
    width: 275,
    borderRadius: 10,
    borderWidth: 1,
    fontSize: 20,
  },
  inputView: {
    paddingHorizontal: 20,
    position: 'absolute',
    bottom: 20,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  btnshape: {
    backgroundColor: '#3498db',
    marginLeft: 20,
    width: 50,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default DetailPostScreen